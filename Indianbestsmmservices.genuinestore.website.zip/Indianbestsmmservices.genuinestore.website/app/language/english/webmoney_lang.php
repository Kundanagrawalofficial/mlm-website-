<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * PerfectMoney
 *
 */
$lang["webmoney"] = "Webmoney";
