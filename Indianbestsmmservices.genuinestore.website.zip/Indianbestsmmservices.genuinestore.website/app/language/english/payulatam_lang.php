<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Payulatam
 *
 */
$lang["payulatam_confirm_form"] = "Payulatam Confirm Form";
$lang["the_system_will_convert_automatically_from_cop_to_usd_and_add_funds_to_your_blance_when_payment_is_made"] = "The system will convert automatically from COP to USD and add funds to your blance when payment is made";
$lang["Deposit_to_"] = "Deposit to ";
$lang["clicking_return_to_shop_merchant_after_payment_successfully_completed"] = "Clicking <strong class='text-danger'>Return to Shop (Merchant)</strong> after payment successfully completed";