<?
/***********************************************************************/
/*                                                                     */
/*  This file is created by deZender                                   */
/*                                                                     */
/*  deZender (Decoder for Zend Encoder/SafeGuard):                     */
/*    Version:      0.9.3.0                                            */
/*    Author:       qinvent.com                                        */
/*    Release on:   2005.11.12                                         */
/*                                                                     */
/***********************************************************************/


  echo '  <tr> 
    <td height="19" bgcolor="ff8d00"><div align="center" class="forCopyright">Powered with HYIP Manager. <a href=http://www.goldrippers.info class="forCopyright">Goldrippers.info</a></div></td>
  </tr>
</table>
</center></body>
</html>
';
?>
