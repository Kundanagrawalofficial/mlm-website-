<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Mercadopago
 *
 */
$lang["mercadopago_payment_form"] = "Mercadopago payment form";
$lang["card_holder_name"] = "Card holder name:";
$lang["document_number"] = "Document number:";