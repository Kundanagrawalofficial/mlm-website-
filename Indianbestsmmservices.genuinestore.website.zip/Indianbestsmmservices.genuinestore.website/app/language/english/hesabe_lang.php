<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Hesabe
 *
 */
$lang["hesabe"]    = "Hesabe";
$lang["the_system_will_convert_automatically_from_KWD_to_USD_and_add_funds_to_your_blance_when_payment_is_made"] = "The system will convert automatically from KWD to USD and add funds to your blance when payment is made";