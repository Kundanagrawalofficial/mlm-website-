<?/*
site_name	Your site
site_url	http://www.YourSite.com
site_url_alt	http://yoursite.com
def_payee_account	
def_payee_name	
	
site_start_day	1
site_start_month	1
site_start_year	2005
hostname	localhost
database	hyip
db_login	root
db_pass		
show_stats_box	1
show_members_stats	1
show_paidout_stats	1
show_top10_stats	1
show_last10_stats	1
show_info_box	1
show_info_box_started	1
show_info_box_running_days	1
show_info_box_total_accounts	1
show_info_box_active_accounts	1
show_info_box_deposit_funds	1
show_info_box_total_withdraw	1
show_info_box_visitor_online	1
show_info_box_members_online	1
show_info_box_last_update	1
show_kitco_dollar_per_ounce_box	1
show_kitco_euro_per_ounce_box	1
use_opt_in	0
opt_in_email	do-not-reply@yoursite.com
use_only_active_members	1
system_email	do-not-reply@yoursite.com
usercanchangeegoldacc	1
usercanchangeemail	1
sendnotify_when_userinfo_changed	1
graph_validation	0
graph_max_chars	6
graph_text_color	#ff8d00
graph_bg_color	#FFFFFF
md5altphrase
use_referal_program	1	
license	1234567
min_auto_withdraw	0.01
max_auto_withdraw	100
use_auto_payment	0
max_auto_withdraw_user	150
show_news_box	0
last_news_count	5
enable_calculator	1
*/?>
