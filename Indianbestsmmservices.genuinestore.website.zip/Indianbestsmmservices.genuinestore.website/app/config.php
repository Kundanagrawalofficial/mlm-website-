<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'tdfilbej_smm1');
define('DB_PASS', 'tdfilbej_smm1');
define('DB_NAME', 'tdfilbej_smm1');
define('TIMEZONE', 'Africa/Abidjan');
define('ENCRYPTION_KEY', '0d89abce3ebf09564affad5da758d9ae');
