<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 *
 * Coinbase
 *
 */
$lang["coinbase_confirm_form"] = "Coinbase Confirm Form";
$lang["coinbase_confirm_form_note"] = 'After Click "Submit", you will be redirected to Coinbase Commerce to commplete your Deposit payment securely.';


